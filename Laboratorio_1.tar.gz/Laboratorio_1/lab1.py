import pygame
import os
from pygame.locals import *
from ast import literal_eval

Verde = (0,255,0)
Rojo = (255,0,0)
Negro = (0,0,0)

colorR = (255, 255, 255, 255)
rectan = pygame.Surface((20, 20))
wall = []
file = open("./juego.txt","r")

start = literal_eval(file.readline())
goal = literal_eval(file.readline())
for line in file:
    wall.append(literal_eval(line))

print(type(start))
print("Start: "+str(start))
print("Goal: "+str(goal))
print("Wall: "+str(wall))


pygame.init()
window = pygame.display.set_mode((600,600))
pygame.display.set_caption("MY OWN PAINT")

color = pygame.Color(255,255,255)
window.fill(color)

color2 = pygame.Color(0,0,0)
for x in range(30):
    posx = x*20
    pygame.draw.line(window,color2,(posx,0),(posx,600))
for y in range(30):
    posy = y*20
    pygame.draw.line(window,color2,(0,posy),(600,posy))

x = int(goal[0])*20
y = int(goal[1])*20
rectan.fill(Verde)
window.blit(rectan, (x,y))
x = int(start[0])*20
y = int(start[1])*20
rectan.fill(Rojo)
window.blit(rectan, (x,y))
for pos in wall:
    x = int(pos[0])*20
    y = int(pos[1])*20
    rectan.fill(Negro)
    window.blit(rectan, (x,y))

while True:
    evento = pygame.event.wait()

    if evento.type == pygame.QUIT:
        break

    pygame.display.update()
